const encoder=new TextEncoder();
const hex=b=>[...new Uint8Array(b)].map(v=>v.toString(16).padStart(2,'0')).join('');
const digest=async s=>hex(await crypto.subtle.digest('SHA-256',encoder.encode(s)));
async function signature(value,secret){const key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',key,encoder.encode(value)))}
async function authorized(request,env){if(!env.ADMIN_SESSION_SECRET)return false;const cookie=request.headers.get('Cookie')||'',m=cookie.match(/(?:^|;\s*)survey_admin=([a-f0-9]+\.[0-9]+\.[a-f0-9]+)/);if(!m)return false;const [nonce,expiry,mac]=m[1].split('.');if(Number(expiry)<Date.now())return false;return mac===await signature(nonce+'.'+expiry,env.ADMIN_SESSION_SECRET)}
const attempts=new Map();
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
async function handle(request,env){const url=new URL(request.url),path=url.pathname;const questions=JSON.parse(ASSETS['questions.json']);
if(path==='/api/admin/login'){
 if(request.method!=='POST')return json({error:'Method'},405);if(request.headers.get('Origin')!==url.origin)return json({error:'Origin'},403);if(!env.ADMIN_PASSWORD_HASH||!env.ADMIN_SESSION_SECRET)return json({error:'Configuration'},503);
 const key=request.headers.get('cf-connecting-ip')||'unknown';const now=Date.now();let attempt=attempts.get(key);if(!attempt||attempt.until<now)attempt={count:0,until:now+900000};if(attempt.count>=10)return json({error:'Too many attempts'},429);
 let body;try{const text=await request.text();if(text.length>500)return json({error:'Invalid'},400);body=JSON.parse(text)}catch{return json({error:'Invalid'},400)}
 if(typeof body.password!=='string'||await digest(body.password)!==env.ADMIN_PASSWORD_HASH){attempt.count++;attempts.set(key,attempt);if(attempts.size>2000)attempts.delete(attempts.keys().next().value);return json({error:'Password'},401)}
 attempts.delete(key);const value=crypto.randomUUID().replaceAll('-','')+'.'+(now+28800000);const token=value+'.'+await signature(value,env.ADMIN_SESSION_SECRET);return new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json','Cache-Control':'no-store','Set-Cookie':'survey_admin='+token+'; Path=/api; HttpOnly; Secure; SameSite=Strict; Max-Age=28800'}});
}
if(path==='/api/admin/logout'){if(request.method!=='POST')return json({error:'Method'},405);if(request.headers.get('Origin')!==url.origin)return json({error:'Origin'},403);return new Response('{}',{headers:{'Content-Type':'application/json','Cache-Control':'no-store','Set-Cookie':'survey_admin=; Path=/api; HttpOnly; Secure; SameSite=Strict; Max-Age=0'}})}
if(path==='/api/responses'){
 if(request.method!=='POST')return json({error:'Method'},405);
 if(![url.origin,'https://chumai9128-cloud.github.io'].includes(request.headers.get('Origin'))||!request.headers.get('Content-Type')?.startsWith('application/json'))return json({error:'Origin'},403);
 if(Number(request.headers.get('Content-Length')||0)>16000)return json({error:'Size'},413);
 let body;try{const raw=await request.text();if(raw.length>16000)return json({error:'Size'},413);body=JSON.parse(raw)}catch{return json({error:'JSON'},400)}
 if(body.version!==2||body.eligible!==true||typeof body.id!=='string'||!/^[-0-9a-f]{36}$/.test(body.id)||!Array.isArray(body.answers)||body.answers.length!==9)return json({error:'Invalid'},400);
 if(body.respondentName!==undefined&&(typeof body.respondentName!=='string'||body.respondentName.length>50))return json({error:'Name'},400);
 const clean=[];for(const q of questions){const matches=body.answers.filter(a=>a&&a.id===q.id);if(matches.length!==1)return json({error:'Answers'},400);const a=matches[0];if(q.id===9){if(typeof a.text!=='string'||a.text.length>1000)return json({error:'Text'},400);clean.push({id:9,text:a.text.trim()});continue}if(q.id===1&&a.choice===2)return json({error:'Not eligible'},400);if(!Number.isInteger(a.choice)||a.choice<0||a.choice>=q.options.length)return json({error:'Choice'},400);const other=q.options[a.choice]==='기타'?a.other:'';if(typeof other!=='string'||other.length>200||(q.options[a.choice]==='기타'&&!other.trim()))return json({error:'Other'},400);clean.push({id:q.id,choice:a.choice,other:other.trim()})}
 if(!env.BUCKET)return json({error:'Storage'},503);const key='responses/v2/'+body.id+'.json';try{const record={id:body.id,version:2,createdAt:new Date().toISOString(),respondentName:(body.respondentName||'').trim(),answers:clean};await env.BUCKET.put(key,JSON.stringify(record),{onlyIf:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'application/json'}});return json({ok:true,id:body.id})}catch{return json({error:'Save'},503)}
}
if(path==='/api/results'){
 if(request.method!=='GET')return json({error:'Method'},405);if(!await authorized(request,env))return json({error:'Sign in'},401);
 if(!env.BUCKET)return json({error:'Storage'},503);try{const list=await env.BUCKET.list({prefix:'responses/v2/',limit:100,cursor:url.searchParams.get('cursor')||undefined});const records=await Promise.all(list.objects.map(async o=>{const r=await env.BUCKET.get(o.key);return r?await r.json():null}));return json({records:records.filter(Boolean),cursor:list.truncated?list.cursor:null})}catch{return json({error:'Read'},503)}
}
if(request.method!=='GET'&&request.method!=='HEAD')return new Response('Method not allowed',{status:405});const name=path==='/'?'index.html':(path==='/admin'||path==='/dashboard')?'admin.html':path.slice(1);if(!Object.hasOwn(ASSETS,name))return new Response('Not found',{status:404});const type=name.endsWith('.js')?'application/javascript':name.endsWith('.json')?'application/json':'text/html';return new Response(request.method==='HEAD'?null:ASSETS[name],{headers:{'Content-Type':type+'; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'self' https://chatgpt.com; base-uri 'self'; form-action 'self'"}})

}
export default {async fetch(request,env){
 const url=new URL(request.url),origin=request.headers.get('Origin');
 const cross=url.pathname==='/api/responses'&&origin==='https://chumai9128-cloud.github.io';
 if(request.method==='OPTIONS'&&url.pathname==='/api/responses'){
  if(!cross)return new Response(null,{status:403});
  return new Response(null,{status:204,headers:{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Methods':'POST','Access-Control-Allow-Headers':'Content-Type','Access-Control-Max-Age':'600','Vary':'Origin'}});
 }
 const response=await handle(request,env);
 if(!cross)return response;
 const headers=new Headers(response.headers);headers.set('Access-Control-Allow-Origin',origin);headers.set('Vary','Origin');
 return new Response(response.body,{status:response.status,headers});
}};
