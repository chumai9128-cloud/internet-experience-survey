import fs from 'node:fs';
const assets={};for(const n of ['index.html','app.js','i18n.js','questions.json','admin.html','admin.js'])assets[n]=fs.readFileSync('frontend/'+n,'utf8');
const source=fs.readFileSync('worker/handler.mjs','utf8');fs.writeFileSync('worker/index.js','const ASSETS='+JSON.stringify(assets)+';\n'+source);
